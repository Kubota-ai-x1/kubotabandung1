<!-- BEGIN:nextjs-agent-rules -->

# This is NOT the Next.js you know

This version has breaking changes — APIs, conventions, and file structure may all differ from your training data. Read the relevant guide in `node_modules/next/dist/docs/` (resolved from this file's directory; in monorepos the `next` package may not be visible from the repo root) before writing any code. Heed deprecation notices.

This block is written and re-added by `next dev` — verify at `node_modules/next/dist/server/lib/generate-agent-files.js`. Removing it from a diff only re-creates the uncommitted change; committing it with your work keeps the tree clean.

<!-- END:nextjs-agent-rules -->

# AGENTS.md

This repository is a Next.js storefront for KUBOTA PARTPRO. The app is a marketing/landing-site project using the App Router, with the main landing experience in `app/page.js`, shared styling in `app/globals.css`, reusable UI pieces in `lib/components/`, and config values in `lib/shopConfig.js`.

## Project realities
- Prefer the existing App Router structure in `app/` instead of introducing alternative patterns.
- This project is mostly a single-page branded landing experience; keep changes focused and consistent with the current visual direction.
- Use `'use client'` for components that manage local state, toggles, or modal interactions.
- Do not touch generated output under `.next/`, lockfiles, or dependencies unless a task explicitly changes project setup.
- Styling is centralized in `app/globals.css`; add or adjust classes there when UI changes need to match the visual language.

## Working conventions
- Keep copy and branding aligned with the existing Thai/English mix used in the site.
- Reuse the existing component organization: page-level composition in `app/page.js`, shared sections in `lib/components/*`, and configuration in `lib/*.js`.
- If new external credentials or API keys are needed, prefer environment variables over hardcoded values.
- When troubleshooting, check `package.json` scripts first and keep changes minimal to the relevant feature.

## Commands
- Install dependencies: `npm install`
- Run development server: `npm run dev`
- Production build: `npm run build`

## Typical edit locations
- Main landing page and modal logic: `app/page.js`
- Shared visual language and layout styling: `app/globals.css`
- Shared business metadata and links: `lib/shopConfig.js`
- Firebase setup: `lib/firebase.js`

## Avoid
- Broad framework migrations, TypeScript conversion, or unnecessary dependency changes.
- Creating parallel app structures or duplicated page logic when a simple update fits the existing design.
- Editing generated Next.js files or hidden build artifacts as part of feature work.
