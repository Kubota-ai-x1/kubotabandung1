---
name: KUBOTA PARTPRO
description: High-craft, velvety dark luxury industrial storefront and equipment discovery experience.
colors:
  canvas: "#040507"
  canvas-soft: "#080a0f"
  canvas-elevated: "#0f131a"
  primary: "#f36c21"
  primary-amber: "#ff7e38"
  primary-deep: "#c2410c"
  primary-bronze: "#ffb088"
  neutral-text: "#f5f6f8"
  neutral-muted: "rgba(195, 202, 215, 0.55)"
  hairline: "rgba(255, 255, 255, 0.08)"
typography:
  display:
    fontFamily: "Barlow Condensed, Arial Narrow, Prompt, sans-serif"
    fontSize: "clamp(2.3rem, 4.4vw, 3.8rem)"
    fontWeight: 800
    lineHeight: 1.04
    letterSpacing: "0.02em"
  headline:
    fontFamily: "Barlow Condensed, Arial Narrow, Prompt, sans-serif"
    fontSize: "clamp(1.8rem, 5vw, 2.5rem)"
    fontWeight: 700
    lineHeight: 1.1
    letterSpacing: "0.01em"
  body:
    fontFamily: "Inter, Prompt, Arial, sans-serif"
    fontSize: "clamp(0.92rem, 1.15vw, 1rem)"
    fontWeight: 300
    lineHeight: 1.75
    letterSpacing: "0.02em"
  label:
    fontFamily: "Inter, Prompt, Arial, sans-serif"
    fontSize: "0.66rem"
    fontWeight: 600
    lineHeight: 1.4
    letterSpacing: "0.22em"
rounded:
  sm: "8px"
  md: "12px"
  lg: "20px"
  xl: "24px"
  pill: "999px"
spacing:
  xs: "6px"
  sm: "12px"
  md: "18px"
  lg: "28px"
  xl: "48px"
components:
  button-primary:
    backgroundColor: "{colors.primary}"
    textColor: "#ffffff"
    rounded: "{rounded.pill}"
    padding: "15px 28px"
  button-ghost:
    backgroundColor: "rgba(255, 255, 255, 0.035)"
    textColor: "{colors.neutral-text}"
    rounded: "{rounded.pill}"
    padding: "15px 28px"
---

# Design System: KUBOTA PARTPRO

## Overview

**Creative North Star: "Obsidian Field Craft"**

KUBOTA PARTPRO delivers an immersive, luxury automotive-industrial atmosphere. Machinery and pre-owned agricultural equipment are presented not as commodity salvage, but as dependable, field-ready heavy craft. The visual interface recedes into a deep, velvety obsidian canvas (`#040507`), allowing the machines to emerge through organic directional gradients, delicate radial spotlight vignettes, and incandescent Kubota amber warmth.

Every surface is engineered to blend seamlessly into the background: no jarring block cuts, no raw 1px wireframe borders, and no abrupt white-flash hover states. Floating panels employ frosted smoked obsidian glass (`rgba(10, 13, 18, 0.72)`) with specular top rims, while interactive elements respond with tactile, velvety micro-elevations and warm ambient halos.

**Key Characteristics:**
- **Seamless Atmospheric Continuity:** Multi-stage vertical dissolves eliminate seams between full-height photo bands, creating an infinite, cinematic canvas.
- **Velvety Tactility:** Buttons, cards, and modal sheets feature soft inner light rims, deep drop shadows, and subtle blur rather than harsh lines.
- **Restrained Incandescence:** The signature Kubota orange is tuned into a warm ember ramp (bronze to amber to fiery orange), used purposefully as focal guidance.
- **Refined Bilingual Typography:** Barlow Condensed brings muscular mechanical authority, paired with airy, high-legibility Inter and Prompt body prose.

## Colors

The palette is rooted in velvety obsidian tones, layered with frosted smoke surfaces and illuminated by Kubota's signature incandescent amber.

### Primary
- **Kubota Flame Orange** (#f36c21): Used for the high-priority conversion CTA, key active states, and destination telemetry.
- **Ember Amber** (#ff7e38): Upper highlight stop for glowing primary buttons and warm rim blooms.
- **Burnished Bronze** (#ffb088): Editorial eyebrow text, category accents, and refined hover shifts.
- **Deep Hearth Ochre** (#c2410c): Shadow depth and gradient anchoring for the solid action button.

### Neutral
- **Obsidian Canvas** (#040507): Deep black foundation with subtle cool-charcoal undertones that absorbs ambient light.
- **Soft Velvet Canvas** (#080a0f): Secondary surface background for trust narrative and transitional bands.
- **Smoked Glass Container** (rgba(10, 13, 18, 0.65)): Frosted translucent surface for explore panels and modal dialogs.
- **Pure Crisp Text** (#f5f6f8): Off-white for high-contrast, effortless readability without stark glare.
- **Secondary Slate Text** (rgba(235, 238, 246, 0.76)): Balanced contrast for descriptions and supporting copy.
- **Subtle Hairline** (rgba(255, 255, 255, 0.08)): Delicate divider and container boundary with specular top reflections.

### Named Rules
**The Infinite Seam Rule.** Full-height photo sections must feather softly into the canvas at top and bottom boundaries. No photograph may touch a raw background transition with a sharp horizontal cut.

**The Incandescent Accent Rule.** Orange and amber accents must never cover more than 10% of a screen's surface area. Their power lies in concentrated radiance.

## Typography

**Display Font:** Barlow Condensed (fallback: Arial Narrow, Prompt, sans-serif)  
**Body Font:** Inter & Prompt (fallback: Arial, sans-serif)  

**Character:** Muscular, high-performance display lettering with tight optical rhythm, grounded by clean, open humanist Thai/Latin body type.

### Hierarchy
- **Display** (800, clamp(2.3rem, 4.4vw, 3.8rem), 1.04 line-height): Hero and band statements with subtle drop shadow separation.
- **Headline** (700, clamp(1.8rem, 5vw, 2.5rem), 1.1 line-height): Modal titles, category headers, and section leads.
- **Body** (300, clamp(0.92rem, 1.15vw, 1rem), 1.75 line-height, max 55ch): Explanatory storytelling and specifications.
- **Label / Eyebrow** (600, 0.66rem, 0.22em tracking, uppercase): Precision mechanical metadata with an integrated warm ember rule.

## Layout

The page utilizes a full-viewport vertical storytelling canvas (`100svh`) with proximity snapping. Desktop layouts frame the machinery on one side while providing smoked glass navigational panels on the other. Mobile layouts fold cleanly into responsive touch carousels with tabular dot indicators. Spacing scales from 12px micro-gaps to 120px generous breathing rooms.

## Elevation & Depth

Surfaces do not use arbitrary flat shadows. Depth is created through material translucency, frosted backdrop blurs (`16px - 36px`), and layered specular lighting.

### Shadow Vocabulary
- **Tactile Floating Button** (`box-shadow: inset 0 1px 1px rgba(255,255,255,0.14), 0 10px 24px -6px rgba(0,0,0,0.5)`): Soft pill depth for interactive controls.
- **Incandescent Action Glow** (`box-shadow: inset 0 1px 1px rgba(255,255,255,0.4), 0 12px 32px -4px rgba(234,88,12,0.42)`): Warm halo under conversion triggers.
- **Smoked Glass Sheet** (`box-shadow: inset 0 1px 1px rgba(255,255,255,0.12), 0 32px 80px -15px rgba(0,0,0,0.85)`): Volumetric elevation for modals and search panels.

### Named Rules
**The Specular Rim Rule.** Any elevated translucent card or button must carry an inner 1px white highlight at 8%–14% opacity on its top edge to simulate polished chamfered glass.

## Shapes

- **Pill (999px radius):** Ghost buttons, solid action buttons, index tags, and search/location pill controls.
- **Curved Glass (20px - 24px radius):** Modal sheets, category explore panels, and search results cards.
- **Input Fields (12px radius):** Smooth rounded corners that nest naturally inside parent panels.

## Components

### Buttons
- **Shape:** Pill (999px radius)
- **Primary CTA:** Incandescent gradient (`linear-gradient(135deg, #ff8342, #ea580c 55%, #c2410c)`), white text, warm ember shadow, specular top reflection. Hover gently lifts 2px with expanded ambient bloom.
- **Ghost CTA:** Smoked glass background (`rgba(255,255,255,0.035)`), 1px subtle hairline, off-white text. Hover shifts to soft luminous glow without blinding white inversion.

### Cards / Explore Panels
- **Corner Style:** Rounded (20px)
- **Background:** Smoked obsidian glass (`rgba(10, 13, 18, 0.52)` with `backdrop-filter: blur(24px)`).
- **Internal Padding:** 24px 26px.
- **Interaction:** Item rows shift smoothly 4px with warm bronze accent on hover.

### Inputs & Selects
- **Style:** 12px radius, translucent dark fill (`rgba(255,255,255,0.035)`), subtle hairline border.
- **Focus:** 3px soft Kubota orange halo (`rgba(243, 108, 33, 0.14)`) and warm border transition.

## Do's and Don'ts

### Do:
- **Do** dissolve photographic backgrounds into the canvas with multi-stage linear and radial gradients.
- **Do** use delicate specular inner rims (`inset 0 1px 0 rgba(255,255,255,0.1)`) on glass surfaces.
- **Do** keep text crisp with balanced contrast and subtle text drop shadows over photography.
- **Do** preserve the tactile, velvety feel of buttons with smooth easing (`cubic-bezier(0.16, 1, 0.3, 1)`).

### Don't:
- **Don't** use stark white-inversion hover states that flash harsh contrast into dark mode.
- **Don't** leave raw 1px solid white borders on cards, buttons, or dividers.
- **Don't** create hard horizontal cuts between full-height photo sections.
- **Don't** overuse saturated orange on large backgrounds or text blocks.

