# -*- coding: utf-8 -*-
"""ตรวจการ์ดแนะนำทั้งในหน้าแรกและหน้า all-recommend"""
import re, io, json, os, sys

def report(path):
    h = io.open(path, encoding='utf-8').read()
    arts = re.findall(r'<article class="sr-card-h".*?</article>', h, re.S)
    print('=' * 70)
    print(path, ' -> การ์ด', len(arts))
    for i, a in enumerate(arts, 1):
        name = re.search(r'data-name="([^"]*)"', a).group(1).split(' ')[0]
        g = re.search(r"data-gallery='(\[.*?\])'", a)
        n = last = 0, '-'
        if g:
            items = json.loads(g.group(1))
            n = len(items)
            last = items[-1]['name'].split('·')[-1].strip()
        facts = re.findall(r'<span class="k">([^<]*)</span><span class="v">([^<]*)</span>', a)
        det = re.search(r'<a class="sr-detail"[^>]*href="([^"]*)"', a)
        print('  [%2d] %-16s gal=%-2d last="%s"  -> %s'
              % (i, name, n, last, det.group(1) if det else '???'))
        print('        ' + ' | '.join('%s=%s' % (k, v) for k, v in facts))
    for kw in ('รอข้อมูล', '(จากโพสต์)', '0 บาท'):
        c = h.count(kw)
        print('  %-16s %d' % (kw, c))


for p in ['web-updated/site/all-recommend/index.html', 'web-updated/site/index.html']:
    report(p)
