# -*- coding: utf-8 -*-
"""ข้อมูลอ้างอิงเดียว (single source of truth) — โซนรถไถมือสอง /site/used-tractors/
   ดึงจาก work-img/แนะนำ/แนะนำ.txt หัวข้อ 1-8

กฎการแสดงผล (ตามที่สั่ง):
  1) ดาวน์ 0 บาท            -> แสดง "ฟรีดาวน์"
  2) มีราคาเงินสด + มีดาวน์  -> แสดงทั้งคู่
  3) มีแค่ดาวน์ ไม่มีราคา    -> ช่องราคา = "ติดต่อเซลล์"
  4) ทุกหน้าต้องมีช่องเซลล์ (ชื่อ + เบอร์จาก txt)
"""

# slug : ข้อมูล
DATA = {
    'u6-m108s': dict(
        no=1, model='M108S-B', family='ซีรีส์ M',
        chip='+ใบมีด+ผาน 1 ตัว',
        price='1,090,000.-',          # txt: ราคา 1,090,000 บาท
        down='ฟรีดาวน์',              # txt: ⭐️ฟรีดาวน์ ⭐️0
        down_raw=0,
        year='2568', hours='800 ชม.',
        drivetrain='2WD', equip='ใบมีด + ผาน 1 ตัว',
        seller='ก้อย', phone='098-2057355', tel='0982057355',
        rec='na1', nimg=9,
    ),
    'm8808': dict(
        no=2, model='M8808', family='ซีรีส์ M',
        chip='+อุปกรณ์ 2 ชิ้น',
        price='8xx,xxx.-',            # txt: ราคา 8xx,xxx บาท
        down='50,000 บาท',            # txt: ออกรถ 50,000
        down_raw=50000,
        year='2565', hours='994 ชม.',
        drivetrain='สอบถามร้าน', equip='อุปกรณ์ 2 ชิ้น',
        seller='อุ๋ย', phone='098-1039700', tel='0981039700',
        rec='na2', nimg=5,
    ),
    'm7040-b': dict(
        no=3, model='M7040-B', family='ซีรีส์ M',
        chip='+ใบมีด+ผาน 1 ตัว',
        price='715,000.-',            # txt: ราคา 715,000 บาท
        down='55,000 บาท',            # txt: ⭐️55,000 บาท
        down_raw=55000,
        year='2566', hours='1,100 ชม.',
        drivetrain='2WD', equip='ใบมีด + ผาน 1 ตัว',
        seller='ก้อย', phone='098-2057355', tel='0982057355',
        rec='na3', nimg=9,
    ),
    'mu4902-b': dict(
        no=4, model='MU4902-B', family='ซีรีส์ MU',
        chip='+ใบมีด+ผานใหม่ 1 ตัว',
        price='560,000.-',            # txt: ราคา 560,000 บาท
        down='ฟรีดาวน์',              # txt: ⭐️0
        down_raw=0,
        year='2565', hours='ไมค์ชำรุด',
        drivetrain='สอบถามร้าน', equip='ใบมีด + ผานใหม่ 1 ตัว',
        seller='ก้อย', phone='098-2057355', tel='0982057355',
        rec='na4', nimg=8,
    ),
    'l5018sp': dict(
        no=5, model='L5018SP', family='ซีรีส์ L',
        chip='+บุ้งกี๋มาตรฐาน',
        price='ติดต่อเซลล์',          # txt ไม่มีราคาเงินสด
        down='20,000 บาท',            # txt: ออกรถ 20,000
        down_raw=20000,
        year='2566', hours='769 ชม.',
        drivetrain='สอบถามร้าน', equip='บุ้งกี๋มาตรฐาน',
        seller='อุ๋ย', phone='098-1039700', tel='0981039700',
        rec='na5', nimg=6,
    ),
    'm6240suh-b': dict(
        no=6, model='M6240SUH-B', family='ซีรีส์ M',
        chip='+ใบมีด+ผาน 1 ตัว',
        price='655,000.-',            # txt: ราคา 655,000 บาท
        down='35,000 บาท',            # txt: ดาวน์ 35,000
        down_raw=35000,
        year='2567', hours='1,398 ชม.',
        drivetrain='สอบถามร้าน', equip='ใบมีด + ผาน 1 ตัว',
        seller='เเคท', phone='0610218998', tel='0610218998',
        rec='na6', nimg=4,
    ),
    'mu5702-b': dict(
        no=7, model='MU5702-B', family='ซีรีส์ MU',
        chip='+ใบมีด+ผาน 1 ตัว',
        price='ติดต่อเซลล์',          # txt ไม่มีราคาเงินสด
        down='25,000 บาท',            # txt: ดาวน์ 25,000
        down_raw=25000,
        year='2567', hours='1,643 ชม.',
        drivetrain='สอบถามร้าน', equip='ใบมีด + ผาน 1 ตัว',
        seller='โอม', phone='098-8264663', tel='0988264663',
        rec='na7', nimg=5,
    ),
    'm7508': dict(
        no=8, model='M7508 (W)', family='ซีรีส์ M',
        chip='+ใบมีด+ผาน 1 ตัว',
        price='ติดต่อเซลล์',          # txt ไม่มีราคาเงินสด
        down='140,000 บาท',           # txt: ดาวน์ 140,000
        down_raw=140000,
        year='2568', hours='628 ชม.',
        drivetrain='สอบถามร้าน', equip='ใบมีด + ผาน 1 ตัว',
        seller='กุ้ง', phone='0610180483', tel='0610180483',
        rec='na8', nimg=7,
    ),
}

# ลำดับการแสดงบนหน้าแนะนำ (ตรงหัวข้อไฟล์ 1-8)
ORDER = ['u6-m108s', 'm8808', 'm7040-b', 'mu4902-b',
         'l5018sp', 'm6240suh-b', 'mu5702-b', 'm7508']


def price_label(p):
    return 'ราคาเงินสด' if not p.startswith('ติดต่อ') else 'ราคาเงินสด'


if __name__ == '__main__':
    print('%-13s %-4s %-14s %-16s %-14s %-9s %s' %
          ('slug', '#', 'ราคา', 'ดาวน์', 'เซลล์', 'เบอร์', 'รูป'))
    print('-' * 90)
    for s in ORDER:
        d = DATA[s]
        print('%-13s %-4d %-14s %-16s %-14s %-9s %s/%d' %
              (s, d['no'], d['price'], d['down'], d['seller'],
               d['phone'], d['rec'], d['nimg']))
