# -*- coding: utf-8 -*-
"""ซ่อม RSC payload: แทนที่ 'ทั้งแถว' ของการ์ดเซลล์ให้เป็นการ์ดแบบบาง
   ใช้ payload ชิ้นเดียว (ถอด self.__next_f ทุก chunk แล้วประกอบกลับ)
   ใช้: python fix_repair.py [--apply]"""
import io, re, sys, glob

APPLY = '--apply' in sys.argv
PHONE = {'u6-m108s': '098-2057355', 'm7040-b': '098-2057355',
         'mu4902-b': '098-2057355', 'l5018sp': '098-1039700',
         'm6240suh-b': '0610218998', 'mu5702-b': '098-8264663',
         'm7508': '0610180483', 'm8808': '098-1039700'}
PUSH = re.compile(r'self\.__next_f\.push\(')

HTML_ROW = ('<section class="sd-sellercard sd-sellercard-slim" '
            'aria-label="เบอร์เซลล์ประจำคัน">'
            '<span class="sd-sellercard-role">เซลล์ประจำคันนี้</span>'
            '<span class="sd-sellercard-phone">%s</span></section>')


def node(phone):
    """node ในรูป logical payload (เครื่องหมายคำพูดเปล่า)"""
    q = '"'
    return ('[' + q + '$' + q + ',' + q + 'section' + q + ',null,{'
            + q + 'className' + q + ':' + q + 'sd-sellercard sd-sellercard-slim' + q + ','
            + q + 'aria-label' + q + ':' + q + 'เบอร์เซลล์ประจำคัน' + q + ','
            + q + 'children' + q + ':['
            + '[' + q + '$' + q + ',' + q + 'span' + q + ',null,{'
            + q + 'className' + q + ':' + q + 'sd-sellercard-role' + q + ','
            + q + 'children' + q + ':' + q + 'เซลล์ประจำคันนี้' + q + '}],'
            + '[' + q + '$' + q + ',' + q + 'span' + q + ',null,{'
            + q + 'className' + q + ':' + q + 'sd-sellercard-phone' + q + ','
            + q + 'children' + q + ':' + q + phone + q + '}]]}]')


def read_js_string(s, i):
    i += 1
    out = []
    while i < len(s):
        c = s[i]
        if c == '\\':
            n = s[i + 1]
            if n == 'n': out.append('\n')
            elif n == 'r': out.append('\r')
            elif n == 't': out.append('\t')
            elif n == 'u':
                out.append(chr(int(s[i + 2:i + 6], 16))); i += 4
            else: out.append(n)
            i += 2
        elif c == '"':
            return ''.join(out), i + 1
        else:
            out.append(c); i += 1
    raise ValueError('unterminated string')


def esc_js(s):
    return (s.replace('\\', '\\\\').replace('"', '\\"')
             .replace('\n', '\\n').replace('\r', '\\r').replace('\t', '\\t'))


def split_payload(h):
    parts, pos = [], 0
    while True:
        m = PUSH.search(h, pos)
        if not m:
            break
        i = m.end()
        while i < len(h) and h[i] in ' \t\r\n':
            i += 1
        if i >= len(h) or h[i] != '[':
            pos = m.end(); continue
        j = i + 1
        while h[j] in ' \t\r\n,':
            j += 1
        k = j
        while h[k].isdigit():
            k += 1
        n = int(h[j:k])
        while h[k] in ' \t\r\n,':
            k += 1
        if h[k] != '"':
            pos = m.end(); continue
        data, endq = read_js_string(h, k)
        r = h.find(']', endq)
        parts.append((n, data, m.start(), r + 1))
        pos = r + 1
    return parts


ROW = re.compile(r'(\n?)([0-9a-f]{1,4}):(\[)')


def rows_of(P):
    return [(m.start(), m.end(), m.group(2)) for m in ROW.finditer(P)]


def fix_payload(P, phone):
    """คืน (P ใหม่, สถานะ)"""
    rs = rows_of(P)
    if not rs:
        return P, 'ไม่พบแถว'
    hit = [i for i, (a, b, n) in enumerate(rs)
           if 'sd-sellercard' in P[a:a + 3000]]
    if hit:
        i = hit[0]
        start = rs[i][1]              # หลัง 'NN:['
        end = rs[i + 1][0] if i + 1 < len(rs) else len(P)
        return P[:start] + node(phone) + P[end:], 'แทนที่แถว'
    # ไม่มีแถว -> แทรกต่อท้ายแถว pricebox
    pi = [i for i, (a, b, n) in enumerate(rs)
          if 'sd-pricebox' in P[a:a + 3000]]
    if not pi:
        return P, 'ไม่พบแถวราคา'
    i = pi[0]
    nxt = rs[i + 1][0] if i + 1 < len(rs) else len(P)
    sep = P[nxt:nxt + 1] if P[nxt:nxt + 1] == '\n' else '\n'
    new_id = 'zz'
    add = sep + new_id + ':[' + node(phone)[1:] + ']' + sep + new_id + ':'
    # แทรก ref: เปลี่ยน "$undefined" ที่ตามหลังแถวราคา
    seg = P[rs[i][1]:nxt]
    if '"$undefined"' in seg:
        seg2 = seg.replace('"$undefined"', '"$' + new_id + '"', 1)
        return P[:rs[i][1]] + seg2 + P[nxt:], 'แทรกแถว+ref'
    return P, 'ไม่พบช่อง ref'


rows = []
for p in sorted(glob.glob('web-updated/site/used-tractors/*/index.html')):
    slug = p.replace('\\', '/').split('used-tractors/')[1].split('/')[0]
    h = io.open(p, encoding='utf-8').read()
    phone = PHONE.get(slug)
    if phone is None:
        m = re.search(r'sd-sellercard-phone[^>]*>([0-9+-]+)<', h)
        phone = m.group(1) if m else None
    if not phone:
        rows.append((slug, 'ข้าม', '-')); continue
    parts = split_payload(h)
    if not parts:
        rows.append((slug, 'ไม่พบ payload', phone)); continue
    P = ''.join(d for _, d, _, _ in parts)
    P2, state = fix_payload(P, phone)
    if P2 != P:
        sizes = [len(d) for _, d, _, _ in parts]
        ns = [n for n, _, _, _ in parts]
        chunks, o = [], 0
        for idx, sz in enumerate(sizes):
            take = sz if idx < len(sizes) - 1 else len(P2) - o
            chunks.append((ns[idx], P2[o:o + take])); o += take
        if o < len(P2):
            chunks[-1] = (chunks[-1][0], chunks[-1][1] + P2[o:])
        out, prev = [], 0
        for idx, (n, data) in enumerate(chunks):
            _, _, st, en = parts[idx]
            out.append(h[prev:st])
            out.append('self.__next_f.push([%d,"%s"])' % (n, esc_js(data)))
            prev = en
        out.append(h[prev:])
        h2 = ''.join(out)
        if h2 != h and APPLY:
            io.open(p, 'w', encoding='utf-8').write(h2)
        if h2 != h and not APPLY:
            pass
        rows.append((slug, state if h2 != h else 'ไม่เปลี่ยน', phone))
    else:
        rows.append((slug, state, phone))

print('%-14s %-16s %s' % ('หน้า', 'ผล', 'เบอร์'))
print('-' * 44)
for a, b, c in rows:
    print('%-14s %-16s %s' % (a, b, c))
print('\n*** เขียนทับแล้ว ***' if APPLY else '(dry-run — สั่ง --apply)')
