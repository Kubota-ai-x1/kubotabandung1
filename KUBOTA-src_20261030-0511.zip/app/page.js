'use client';

import Link from 'next/link';
import { useEffect, useRef, useState } from 'react';

const productSections = [
  {
    id: 'tractors',
    category: 'รถไถมือสอง',
    eyebrow: 'PRE-OWNED TRACTORS',
    title: 'พร้อมลุยทุกผืนงาน',
    description: 'รถไถมือสองที่คัดสรรเพื่อการเกษตรและงานในไร่ พร้อมข้อมูลให้คุณเลือกได้ตรงกับการใช้งาน',
    image:
      'https://images.unsplash.com/photo-1791807028600-b78d90e786e9?auto=format&fit=crop&w=2400&q=85',
    position: 'center 55%',
  },
  {
    id: 'harvesters',
    category: 'รถเกี่ยวมือสอง',
    eyebrow: 'PRE-OWNED HARVESTERS',
    title: 'เก็บเกี่ยวได้เต็มประสิทธิภาพ',
    description: 'เลือกเครื่องจักรสำหรับฤดูกาลเก็บเกี่ยว พร้อมคำแนะนำจากทีมงานก่อนตัดสินใจ',
    image:
      'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=2400&q=85',
    position: 'center 55%',
  },
  {
    id: 'excavators',
    category: 'รถขุดมือสอง',
    eyebrow: 'PRE-OWNED EXCAVATORS',
    title: 'แรงพร้อม สำหรับงานหนัก',
    description: 'ตัวเลือกสำหรับงานก่อสร้าง งานถนน และงานที่ต้องการเครื่องจักรพร้อมใช้งาน',
    image:
      'https://images.unsplash.com/photo-1516937941344-00b4e0337589?auto=format&fit=crop&w=2400&q=85',
    position: 'center 55%',
  },
  {
    id: 'genuine-parts',
    category: 'อะไหล่แท้ KUBOTA',
    eyebrow: 'GENUINE KUBOTA PARTS',
    title: 'ดูแลเครื่องจักรด้วยอะไหล่แท้',
    description: 'สอบถามอะไหล่และรับคำแนะนำจากทีมงาน เพื่อให้เหมาะกับรุ่นและการใช้งานของคุณ',
    image:
      'https://images.unsplash.com/photo-1581092160562-40aa08e78837?auto=format&fit=crop&w=2400&q=85',
    position: 'center 55%',
  },
];

const trustPoints = [
  'คำแนะนำตรงกับการใช้งาน',
  'เลือกสินค้าจากประสบการณ์จริง',
  'พูดคุยกับทีมงานได้โดยตรง',
];

const searchItems = [
  {
    id: 'home',
    title: 'หน้าแรก',
    description: 'กลับไปยังภาพแนะนำ KUBOTA PARTPRO',
    keywords: 'home kubota partpro บ้านดุง',
  },
  ...productSections.map((item) => ({
    id: item.id,
    title: item.category,
    description: item.description,
    keywords: `${item.eyebrow} ${item.title} ${item.category}`,
  })),
  {
    id: 'new-tractors',
    title: 'รถไถคูโบต้า มือหนึ่ง',
    description: 'แทรกเตอร์คูโบต้า รุ่น B, L, MU และ M',
    keywords: 'รถไถ มือหนึ่ง แทรกเตอร์ รุ่น B รุ่น L รุ่น MU รุ่น M',
    href: '/products/tractors',
  },
  {
    id: 'new-harvesters',
    title: 'รถเกี่ยวคูโบต้า มือหนึ่ง',
    description: 'รถเกี่ยวนวดข้าวคูโบต้า',
    keywords: 'รถเกี่ยว มือหนึ่ง รถเกี่ยวนวดข้าว',
    href: '/products/harvesters',
  },
  {
    id: 'new-excavators',
    title: 'รถขุดคูโบต้า มือหนึ่ง',
    description: 'รถขุดคูโบต้า',
    keywords: 'รถขุด มือหนึ่ง',
    href: '/products/excavators',
  },
  {
    id: 'new-tractor-implements',
    title: 'อุปกรณ์ต่อพ่วงแทรกเตอร์คูโบต้า',
    description: 'อุปกรณ์ต่อพ่วงสำหรับใช้งานร่วมกับแทรกเตอร์',
    keywords: 'อุปกรณ์ต่อพ่วงแทรกเตอร์ รถไถ มือหนึ่ง',
    href: '/products/tractor-implements',
  },
  {
    id: 'about',
    title: 'เกี่ยวกับเรา',
    description: 'แนวทางการเลือกสินค้าและทีมงาน',
    keywords: 'about team ทีมงาน คำแนะนำ',
  },
  {
    id: 'contact',
    title: 'ติดต่อทีมงาน',
    description: 'ไปยังส่วนติดต่อและสอบถาม',
    keywords: 'contact ติดต่อ สอบถาม',
  },
  {
    id: 'location',
    title: 'ตำแหน่งร้าน',
    description: 'ดูเส้นทางไปคูโบต้า บ้านดุง',
    keywords: 'location map แผนที่ บ้านดุง อุดรธานี',
    action: 'location',
  },
];

const initialFormData = {
  category: productSections[0].category,
  condition: 'ปานกลาง',
  budget: '300,000 - 600,000',
  name: '',
  phone: '',
};

export default function HomePage() {
  const [isEstimateOpen, setEstimateOpen] = useState(false);
  const [isLocationOpen, setLocationOpen] = useState(false);
  const [locationStage, setLocationStage] = useState(0);
  const [submitted, setSubmitted] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [newProductMenuOpen, setNewProductMenuOpen] = useState(false);
  const [isScrolled, setScrolled] = useState(false);
  const [isSearchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeHeroSlide, setActiveHeroSlide] = useState(0);
  const [formData, setFormData] = useState(initialFormData);
  const touchStart = useRef(null);

  const normalizedQuery = searchQuery.trim().toLocaleLowerCase('th');
  const searchTerms = normalizedQuery.split(/\s+/).filter(Boolean);
  const searchResults = searchTerms.length
    ? searchItems.filter((item) => {
        const searchableText = `${item.title} ${item.description} ${item.keywords}`
          .toLocaleLowerCase('th');
        return searchTerms.every((term) => searchableText.includes(term));
      })
    : searchItems.slice(1, 4);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 24);
    handleScroll();
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  useEffect(() => {
    if (!isEstimateOpen && !isLocationOpen && !isSearchOpen) return undefined;

    const closeOnEscape = (event) => {
      if (event.key === 'Escape') {
        setEstimateOpen(false);
        setLocationOpen(false);
        setSearchOpen(false);
      }
    };

    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', closeOnEscape);

    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', closeOnEscape);
    };
  }, [isEstimateOpen, isLocationOpen, isSearchOpen]);

  useEffect(() => {
    if (!isLocationOpen) return undefined;

    setLocationStage(0);
    const stages = [
      window.setTimeout(() => setLocationStage(1), 900),
      window.setTimeout(() => setLocationStage(2), 2250),
      window.setTimeout(() => setLocationStage(3), 3350),
    ];

    return () => stages.forEach(window.clearTimeout);
  }, [isLocationOpen]);

  const openEstimate = (category = initialFormData.category) => {
    setFormData({ ...initialFormData, category });
    setSubmitted(false);
    setEstimateOpen(true);
    setMenuOpen(false);
  };

  const selectSearchResult = (item) => {
    setSearchOpen(false);
    setSearchQuery('');
    if (item.action === 'location') {
      setLocationOpen(true);
      return;
    }
    if (item.href) {
      window.location.href = item.href;
      return;
    }

    document.getElementById(item.id)?.scrollIntoView({
      behavior: 'smooth',
      block: 'start',
    });
  };

  const moveHeroSlide = (direction) => {
    setActiveHeroSlide((current) =>
      Math.max(0, Math.min(productSections.length - 1, current + direction)),
    );
  };

  const handleCarouselTouchStart = (event) => {
    const touch = event.changedTouches[0];
    touchStart.current = { x: touch.clientX, y: touch.clientY };
  };

  const handleCarouselTouchEnd = (event) => {
    if (!touchStart.current) return;

    const touch = event.changedTouches[0];
    const deltaX = touch.clientX - touchStart.current.x;
    const deltaY = touch.clientY - touchStart.current.y;
    touchStart.current = null;

    if (Math.abs(deltaX) < 48 || Math.abs(deltaX) <= Math.abs(deltaY)) return;
    moveHeroSlide(deltaX < 0 ? 1 : -1);
  };

  const handleChange = (event) => {
    const { name, value } = event.target;
    setFormData((current) => ({ ...current, [name]: value }));
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    setSubmitted(true);
  };

  return (
    <main className="site-shell">
      <header className={`site-header${isScrolled ? ' is-scrolled' : ''}`}>
        <div className="brand-tools">
          <a className="brand-mark" href="#home" aria-label="KUBOTA PARTPRO หน้าแรก">
            <span className="brand-kubota">KUBOTA</span>
            <span className="brand-part">PARTPRO</span>
          </a>
          <button
            type="button"
            className="location-trigger"
            aria-label="เปิดตำแหน่งร้านคูโบต้า บ้านดุง"
            onClick={() => {
              setLocationOpen(true);
              setMenuOpen(false);
            }}
          >
            <span className="location-trigger-icon" aria-hidden="true">⌖</span>
            <span>LOCATION</span>
          </button>
        </div>

        <div className="header-controls">
          <button
            type="button"
            className="search-trigger"
            aria-label="ค้นหาหมวดสินค้าและข้อมูลในเว็บไซต์"
            onClick={() => {
              setSearchQuery('');
              setSearchOpen(true);
              setMenuOpen(false);
            }}
          >
            <svg viewBox="0 0 24 24" aria-hidden="true">
              <circle cx="10.8" cy="10.8" r="6.5" />
              <path d="m16 16 4.2 4.2" />
            </svg>
          </button>

          <button
            type="button"
            className={`menu-toggle${menuOpen ? ' is-open' : ''}`}
            aria-label={menuOpen ? 'ปิดเมนู' : 'เปิดเมนู'}
            aria-expanded={menuOpen}
            aria-controls="site-navigation"
            onClick={() => {
              setMenuOpen((open) => !open);
              setNewProductMenuOpen(false);
            }}
          >
            <span />
            <span />
          </button>

          <nav
            className={`site-nav${menuOpen ? ' is-open' : ''}`}
            id="site-navigation"
            aria-label="เมนูหลัก"
          >
            <a href="#home" onClick={() => setMenuOpen(false)}>หน้าแรก</a>
            <div className={`site-nav-products${newProductMenuOpen ? ' is-open' : ''}`}>
              <button
                type="button"
                className="new-products-toggle"
                aria-expanded={newProductMenuOpen}
                aria-controls="new-products-menu"
                onClick={() => setNewProductMenuOpen((open) => !open)}
              >
                สินค้าใหม่มือหนึ่ง
                <span className="new-products-chevron" aria-hidden="true" />
              </button>
              {newProductMenuOpen && (
                <div className="new-products-menu" id="new-products-menu">
                  <Link href="/products/tractors" onClick={() => { setMenuOpen(false); setNewProductMenuOpen(false); }}>
                    <span>รถไถ</span><span aria-hidden="true">↗</span>
                  </Link>
                  <Link href="/products/harvesters" onClick={() => { setMenuOpen(false); setNewProductMenuOpen(false); }}>
                    <span>รถเกี่ยว</span><span aria-hidden="true">↗</span>
                  </Link>
                  <Link href="/products/excavators" onClick={() => { setMenuOpen(false); setNewProductMenuOpen(false); }}>
                    <span>รถขุด</span><span aria-hidden="true">↗</span>
                  </Link>
                  <Link href="/products/tractor-implements" onClick={() => { setMenuOpen(false); setNewProductMenuOpen(false); }}>
                    <span>อุปกรณ์ต่อพ่วงแทรกเตอร์</span><span aria-hidden="true">↗</span>
                  </Link>
                </div>
              )}
            </div>
            <a href="#about" onClick={() => setMenuOpen(false)}>เกี่ยวกับเรา</a>
            <button type="button" onClick={() => openEstimate()}>
              ประเมินราคา
            </button>
          </nav>
        </div>
      </header>

      <section
        className="photo-band hero-band"
        id="home"
        style={{
          '--band-image': "url('/kubota-bandung-shop.png')",
          '--image-position': 'center 48%',
        }}
      >
        <div className="band-content hero-content">
          <div className="hero-copy">
            <p className="eyebrow">KUBOTA BAN DUNG · PARTPRO</p>
            <h1>เครื่องจักรพร้อมลุย<br />ทุกงานของคุณ</h1>
            <p className="band-description">
              รถมือสองและอะไหล่ KUBOTA พร้อมคำแนะนำที่เข้าใจการใช้งานจริง
            </p>
            <div className="hero-actions">
              <a className="ghost-button" href="#products">
                สำรวจสินค้า <span aria-hidden="true">↓</span>
              </a>
              <button type="button" className="solid-button" onClick={() => openEstimate()}>
                ประเมินราคา <span aria-hidden="true">↗</span>
              </button>
            </div>
          </div>

          <nav className="hero-explore" aria-label="สำรวจหมวดสินค้า">
            <h2>เลือกดูตามประเภท</h2>
            <div className="hero-explore-list">
              {productSections.map((item) => (
                <a className="hero-explore-link" href={`#${item.id}`} key={item.id}>
                  <span>
                    <span className="hero-explore-category">{item.eyebrow}</span>
                    <span className="hero-explore-title">{item.category}</span>
                  </span>
                  <span aria-hidden="true">↗</span>
                </a>
              ))}
            </div>
          </nav>

          <section
            className="hero-mobile-carousel"
            aria-label="แนะนำหมวดสินค้า"
            aria-roledescription="carousel"
            onTouchStart={handleCarouselTouchStart}
            onTouchEnd={handleCarouselTouchEnd}
            onTouchCancel={() => { touchStart.current = null; }}
          >
            <div
              key={activeHeroSlide}
              className="hero-slide"
              role="group"
              aria-roledescription="สไลด์"
              aria-label={`${activeHeroSlide + 1} จาก ${productSections.length}`}
              aria-live="polite"
            >
              <p className="hero-slide-category">{productSections[activeHeroSlide].eyebrow}</p>
              <h2>{productSections[activeHeroSlide].title}</h2>
              <p>{productSections[activeHeroSlide].description}</p>
              <a href={`#${productSections[activeHeroSlide].id}`}>
                ดูหมวดนี้ <span aria-hidden="true">↗</span>
              </a>
            </div>
            <div className="hero-carousel-controls">
              <button
                type="button"
                className="hero-carousel-arrow"
                aria-label="ดูหมวดก่อนหน้า"
                disabled={activeHeroSlide === 0}
                onClick={() => moveHeroSlide(-1)}
              >
                <svg viewBox="0 0 24 24" aria-hidden="true">
                  <path d="m15 18-6-6 6-6" />
                </svg>
              </button>
              <div className="hero-carousel-dots" aria-label="เลือกหมวดสินค้า">
                {productSections.map((item, index) => (
                  <button
                    type="button"
                    className={index === activeHeroSlide ? 'is-active' : ''}
                    aria-label={`แสดง ${item.category}`}
                    aria-current={index === activeHeroSlide ? 'step' : undefined}
                    key={item.id}
                    onClick={() => setActiveHeroSlide(index)}
                  />
                ))}
              </div>
              <span className="hero-carousel-count">
                {String(activeHeroSlide + 1).padStart(2, '0')} / {String(productSections.length).padStart(2, '0')}
              </span>
              <button
                type="button"
                className="hero-carousel-arrow"
                aria-label="ดูหมวดถัดไป"
                disabled={activeHeroSlide === productSections.length - 1}
                onClick={() => moveHeroSlide(1)}
              >
                <svg viewBox="0 0 24 24" aria-hidden="true">
                  <path d="m9 18 6-6-6-6" />
                </svg>
              </button>
            </div>
          </section>
          </div>
        <a className="scroll-cue" href="#products" aria-label="เลื่อนลงเพื่อดูสินค้า">
          <span />
        </a>
      </section>

      <div id="products">
        {productSections.map((item, index) => (
          <section
            className={`photo-band product-band${index % 2 ? ' align-right' : ''}`}
            id={item.id}
            key={item.id}
            style={{
              '--band-image': `url("${item.image}")`,
              '--image-position': item.position,
            }}
          >
            <div className="band-content">
              <p className="eyebrow">{item.eyebrow}</p>
              <p className="band-index">0{index + 1} / 04</p>
              <h2>{item.title}</h2>
              <p className="band-description">{item.description}</p>
              <button
                type="button"
                className="ghost-button"
                onClick={() => openEstimate(item.category)}
              >
                สอบถาม{item.category}
                <span aria-hidden="true">↗</span>
              </button>
            </div>
          </section>
        ))}
      </div>

      <section
        className="photo-band about-band"
        id="about"
        style={{
          '--band-image':
            'url("https://images.unsplash.com/photo-1499529112087-3cb3b73cec95?auto=format&fit=crop&w=2400&q=85")',
          '--image-position': 'center 55%',
        }}
      >
        <div className="band-content">
          <p className="eyebrow">WHY KUBOTA PARTPRO</p>
          <h2>เลือกได้มั่นใจ<br />มีทีมงานอยู่ข้างคุณ</h2>
          <ul className="trust-list">
            {trustPoints.map((point, index) => (
              <li key={point}>
                <span>0{index + 1}</span>
                {point}
              </li>
            ))}
          </ul>
          <a className="ghost-button" href="#contact">
            ติดต่อทีมงาน <span aria-hidden="true">↓</span>
          </a>
        </div>
      </section>

      <section className="contact-band" id="contact">
        <div className="contact-copy">
          <p className="eyebrow">YOUR NEXT MOVE STARTS HERE</p>
          <h2>กำลังมองหาเครื่องจักร<br />หรืออะไหล่ที่ใช่?</h2>
        </div>
        <button type="button" className="ghost-button" onClick={() => openEstimate()}>
          คุยกับทีมงาน <span aria-hidden="true">↗</span>
        </button>
        <footer className="site-footer">
          <a className="brand-mark" href="#home" aria-label="กลับขึ้นด้านบน">
            <span className="brand-kubota">KUBOTA</span>
            <span className="brand-part">PARTPRO</span>
          </a>
          <span>คูโบต้า บ้านดุง</span>
          <a href="#home">กลับขึ้นด้านบน ↑</a>
        </footer>
      </section>

      {isEstimateOpen && (
        <div className="modal-backdrop" onClick={() => setEstimateOpen(false)}>
          <section
            className="estimate-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="estimate-title"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="modal-header">
              <div>
                <p className="eyebrow">QUICK ESTIMATE</p>
                <h2 id="estimate-title">เริ่มประเมินความต้องการ</h2>
              </div>
              <button
                type="button"
                className="modal-close"
                aria-label="ปิดหน้าต่าง"
                onClick={() => setEstimateOpen(false)}
              >
                ×
              </button>
            </div>

            {!submitted ? (
              <form className="estimate-form" onSubmit={handleSubmit}>
                <label>
                  ประเภทสินค้า
                  <select name="category" value={formData.category} onChange={handleChange}>
                    {productSections.map((item) => (
                      <option key={item.id}>{item.category}</option>
                    ))}
                  </select>
                </label>
                <label>
                  สภาพรถ/สินค้า
                  <select name="condition" value={formData.condition} onChange={handleChange}>
                    <option>ใหม่</option>
                    <option>ปานกลาง</option>
                    <option>เก่า</option>
                    <option>ต้องการคำปรึกษา</option>
                  </select>
                </label>
                <label>
                  งบประมาณที่คาดหวัง
                  <select name="budget" value={formData.budget} onChange={handleChange}>
                    <option>ต่ำกว่า 300,000</option>
                    <option>300,000 - 600,000</option>
                    <option>600,000 - 1,200,000</option>
                    <option>มากกว่า 1,200,000</option>
                  </select>
                </label>
                <label>
                  ชื่อผู้ติดต่อ
                  <input
                    type="text"
                    name="name"
                    autoComplete="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder="กรอกชื่อของคุณ"
                    required
                  />
                </label>
                <label>
                  เบอร์โทรศัพท์
                  <input
                    type="tel"
                    name="phone"
                    autoComplete="tel"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder="กรอกเบอร์โทรศัพท์"
                    required
                  />
                </label>
                <p className="form-notice">
                  แบบฟอร์มนี้ยังเป็นตัวอย่าง และยังไม่ได้เชื่อมต่อการส่งข้อมูลจริง
                </p>
                <button type="submit" className="ghost-button modal-submit">
                  ดูสรุปรายการ <span aria-hidden="true">→</span>
                </button>
              </form>
            ) : (
              <div className="estimate-summary">
                <p className="eyebrow">YOUR SELECTION</p>
                <h3>{formData.category}</h3>
                <p>สภาพ: {formData.condition}</p>
                <p>งบประมาณ: {formData.budget} บาท</p>
                <p className="form-notice">
                  สรุปนี้แสดงในหน้าเว็บเท่านั้น ยังไม่มีการส่งข้อมูลไปยังทีมงาน
                </p>
                <button
                  type="button"
                  className="ghost-button modal-submit"
                  onClick={() => setEstimateOpen(false)}
                >
                  กลับไปเลือกสินค้า
                </button>
              </div>
            )}
          </section>
        </div>
      )}

      {isSearchOpen && (
        <div className="search-backdrop" onClick={() => setSearchOpen(false)}>
          <section
            className="search-panel"
            role="dialog"
            aria-modal="true"
            aria-labelledby="search-title"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="search-panel-heading">
              <div>
                <p className="eyebrow">KUBOTA PARTPRO</p>
                <h2 id="search-title">ค้นหาสินค้าและข้อมูล</h2>
              </div>
              <button
                type="button"
                className="modal-close"
                aria-label="ปิดการค้นหา"
                onClick={() => setSearchOpen(false)}
              >
                ×
              </button>
            </div>
            <label className="search-field">
              <span className="search-field-icon" aria-hidden="true">
                <svg viewBox="0 0 24 24">
                  <circle cx="10.8" cy="10.8" r="6.5" />
                  <path d="m16 16 4.2 4.2" />
                </svg>
              </span>
              <input
                type="search"
                autoFocus
                value={searchQuery}
                onChange={(event) => setSearchQuery(event.target.value)}
                placeholder="ลองค้นหา รถไถ, อะไหล่, บ้านดุง..."
                aria-label="ค้นหาหมวดสินค้าและข้อมูลในเว็บไซต์"
              />
              {searchQuery && (
                <button
                  type="button"
                  className="search-clear"
                  aria-label="ล้างคำค้นหา"
                  onClick={() => setSearchQuery('')}
                >
                  ล้าง
                </button>
              )}
            </label>
            <div className="search-results" aria-live="polite">
              <p className="search-results-label">
                {normalizedQuery ? 'ผลการค้นหา' : 'หมวดที่ค้นหาบ่อย'}
              </p>
              {searchResults.length ? (
                <ul>
                  {searchResults.map((item) => (
                    <li key={item.id}>
                      {item.action === 'location' ? (
                        <button type="button" onClick={() => selectSearchResult(item)}>
                          <span>
                            <strong>{item.title}</strong>
                            <span>{item.description}</span>
                          </span>
                          <span aria-hidden="true">↗</span>
                        </button>
                      ) : (
                        <a
                          href={item.href || `#${item.id}`}
                          onClick={() => {
                            setSearchOpen(false);
                            setSearchQuery('');
                          }}
                        >
                          <span>
                            <strong>{item.title}</strong>
                            <span>{item.description}</span>
                          </span>
                          <span aria-hidden="true">↗</span>
                        </a>
                      )}
                    </li>
                  ))}
                </ul>
              ) : (
                <p className="search-empty">
                  ยังไม่พบคำที่ตรงกัน ลองค้นหาด้วยชื่อหมวดสินค้า เช่น “รถไถ” หรือ “อะไหล่”
                </p>
              )}
            </div>
          </section>
        </div>
      )}

      {isLocationOpen && (
        <div className="location-backdrop" onClick={() => setLocationOpen(false)}>
          <section
            className="location-modal"
            role="dialog"
            aria-modal="true"
            aria-labelledby="location-title"
            onClick={(event) => event.stopPropagation()}
          >
            <div className="location-heading">
              <div>
                <p className="eyebrow">KUBOTA BAN DUNG · LOCATION</p>
                <h2 id="location-title">เส้นทางสู่บ้านดุง</h2>
              </div>
              <button
                type="button"
                className="modal-close"
                aria-label="ปิดตำแหน่งร้าน"
                onClick={() => setLocationOpen(false)}
              >
                ×
              </button>
            </div>

            <div className={`location-journey stage-${locationStage}`}>
              <div className="route-map" aria-label="เส้นทางจากกรุงเทพฯ ผ่านอุดรธานีไปยังบ้านดุง">
                <div className="route-map-grid" />
                <svg
                  className="thailand-map"
                  viewBox="0 0 360 470"
                  role="img"
                  aria-labelledby="map-title map-description"
                >
                  <defs>
                    <linearGradient id="land-face" x1="0" x2="0.8" y1="0" y2="1">
                      <stop offset="0" stopColor="#b8dce0" stopOpacity="0.22" />
                      <stop offset="0.55" stopColor="#4e7e87" stopOpacity="0.12" />
                      <stop offset="1" stopColor="#10232a" stopOpacity="0.58" />
                    </linearGradient>
                    <linearGradient id="land-side" x1="0" x2="0" y1="0" y2="1">
                      <stop offset="0" stopColor="#557c83" stopOpacity="0.78" />
                      <stop offset="1" stopColor="#0c171b" stopOpacity="0.96" />
                    </linearGradient>
                    <filter id="map-glow" x="-30%" y="-30%" width="160%" height="160%">
                      <feGaussianBlur stdDeviation="2.2" result="blur" />
                      <feMerge>
                        <feMergeNode in="blur" />
                        <feMergeNode in="SourceGraphic" />
                      </feMerge>
                    </filter>
                    <clipPath id="thailand-clip">
                      <path d="M135.2 11.2 L135.9 13.3 L141.6 9.2 L148 15.3 L144.2 27.5 L147.7 33.5 L151.6 35 L162.1 31.8 L170.1 33.5 L172.7 50.1 L165 65.7 L167.9 74.4 L160.5 90.7 L162.1 91.8 L168.8 93 L198.6 72.4 L216.5 83.7 L229 77.6 L236.7 66.6 L257.8 69.2 L273.2 87.2 L283.1 94.2 L285.6 98.8 L283.1 111 L285.6 122.9 L293 131.9 L304.5 136.8 L304.2 141.4 L311.9 146.4 L307.1 158 L309 167.5 L306.8 179.1 L293.6 187.8 L284.4 182 L258.8 184.1 L246.6 182.3 L233.8 184.9 L224.5 190.4 L213 206.7 L205.6 207.8 L211.4 233.1 L219.4 240 L219.1 249.9 L225.2 260.9 L214.6 246.7 L212.7 249.3 L190.3 233.9 L160.2 233.6 L162.1 211 L150.6 207 L132 213.4 L134.3 222.3 L130.1 232.5 L131.1 247.6 L119.6 268.2 L115.1 284.7 L104.5 301.2 L104.5 318.3 L108.7 327.6 L107.4 331.7 L126 331.1 L131.1 351.4 L135.6 356 L136.5 353.7 L140.4 360.7 L148.7 390.8 L145.5 389.4 L143.6 381.8 L140.4 381.5 L139.7 375.2 L136.5 376.3 L136.5 380.1 L144.8 392 L150.3 392.3 L164 401.6 L179.4 401.6 L198.6 419.5 L191.2 431.7 L185.2 432.9 L181.3 429.1 L166.9 436.9 L162.8 433.2 L166 427.7 L165 419.5 L159.2 419.3 L155.7 413.2 L142.6 410.5 L139.7 406.8 L137.2 407.1 L135.2 413.7 L121.8 401 L122.4 394.3 L117 391.1 L118.6 387.1 L110.9 386.8 L107.7 379.5 L102 376.6 L101 371.7 L92.7 366.8 L89.8 361 L86 358.6 L78.9 363 L75.1 356.3 L75.1 346.2 L89.8 305 L91.7 291.4 L105.5 278.3 L118.9 258.9 L112.5 236.5 L106.4 231 L103.6 222.6 L103.9 202.6 L97.2 193 L85.6 184.1 L73.8 166.1 L73.5 159.7 L85.3 154.8 L86.3 135 L93.6 131.3 L95.9 126.3 L94.3 124.3 L88.5 126.9 L81.5 108.1 L58.1 84.3 L55.6 70.1 L49.8 68.1 L47.6 63.4 L59.4 61.4 L58.1 51.5 L61.6 36.2 L68 27.8 L79.2 29.5 L96.8 27.2 L101.6 17.6 L115.1 16.2 L114.1 10.1 L122.4 10.9 L127.9 8.3 Z" />
                    </clipPath>
                  </defs>
                  <title id="map-title">แผนที่ประเทศไทยแบบเอกซเรย์</title>
                  <desc id="map-description">แสดงเส้นทางเคลื่อนไหวจากกรุงเทพมหานคร ผ่านอุดรธานี ไปยังคูโบต้า บ้านดุง</desc>
                  <path
                    className="map-land-side"
                    d="M135.2 11.2 L135.9 13.3 L141.6 9.2 L148 15.3 L144.2 27.5 L147.7 33.5 L151.6 35 L162.1 31.8 L170.1 33.5 L172.7 50.1 L165 65.7 L167.9 74.4 L160.5 90.7 L162.1 91.8 L168.8 93 L198.6 72.4 L216.5 83.7 L229 77.6 L236.7 66.6 L257.8 69.2 L273.2 87.2 L283.1 94.2 L285.6 98.8 L283.1 111 L285.6 122.9 L293 131.9 L304.5 136.8 L304.2 141.4 L311.9 146.4 L307.1 158 L309 167.5 L306.8 179.1 L293.6 187.8 L284.4 182 L258.8 184.1 L246.6 182.3 L233.8 184.9 L224.5 190.4 L213 206.7 L205.6 207.8 L211.4 233.1 L219.4 240 L219.1 249.9 L225.2 260.9 L214.6 246.7 L212.7 249.3 L190.3 233.9 L160.2 233.6 L162.1 211 L150.6 207 L132 213.4 L134.3 222.3 L130.1 232.5 L131.1 247.6 L119.6 268.2 L115.1 284.7 L104.5 301.2 L104.5 318.3 L108.7 327.6 L107.4 331.7 L126 331.1 L131.1 351.4 L135.6 356 L136.5 353.7 L140.4 360.7 L148.7 390.8 L145.5 389.4 L143.6 381.8 L140.4 381.5 L139.7 375.2 L136.5 376.3 L136.5 380.1 L144.8 392 L150.3 392.3 L164 401.6 L179.4 401.6 L198.6 419.5 L191.2 431.7 L185.2 432.9 L181.3 429.1 L166.9 436.9 L162.8 433.2 L166 427.7 L165 419.5 L159.2 419.3 L155.7 413.2 L142.6 410.5 L139.7 406.8 L137.2 407.1 L135.2 413.7 L121.8 401 L122.4 394.3 L117 391.1 L118.6 387.1 L110.9 386.8 L107.7 379.5 L102 376.6 L101 371.7 L92.7 366.8 L89.8 361 L86 358.6 L78.9 363 L75.1 356.3 L75.1 346.2 L89.8 305 L91.7 291.4 L105.5 278.3 L118.9 258.9 L112.5 236.5 L106.4 231 L103.6 222.6 L103.9 202.6 L97.2 193 L85.6 184.1 L73.8 166.1 L73.5 159.7 L85.3 154.8 L86.3 135 L93.6 131.3 L95.9 126.3 L94.3 124.3 L88.5 126.9 L81.5 108.1 L58.1 84.3 L55.6 70.1 L49.8 68.1 L47.6 63.4 L59.4 61.4 L58.1 51.5 L61.6 36.2 L68 27.8 L79.2 29.5 L96.8 27.2 L101.6 17.6 L115.1 16.2 L114.1 10.1 L122.4 10.9 L127.9 8.3 Z"
                  />
                  <path
                    className="map-land-face"
                    d="M135.2 11.2 L135.9 13.3 L141.6 9.2 L148 15.3 L144.2 27.5 L147.7 33.5 L151.6 35 L162.1 31.8 L170.1 33.5 L172.7 50.1 L165 65.7 L167.9 74.4 L160.5 90.7 L162.1 91.8 L168.8 93 L198.6 72.4 L216.5 83.7 L229 77.6 L236.7 66.6 L257.8 69.2 L273.2 87.2 L283.1 94.2 L285.6 98.8 L283.1 111 L285.6 122.9 L293 131.9 L304.5 136.8 L304.2 141.4 L311.9 146.4 L307.1 158 L309 167.5 L306.8 179.1 L293.6 187.8 L284.4 182 L258.8 184.1 L246.6 182.3 L233.8 184.9 L224.5 190.4 L213 206.7 L205.6 207.8 L211.4 233.1 L219.4 240 L219.1 249.9 L225.2 260.9 L214.6 246.7 L212.7 249.3 L190.3 233.9 L160.2 233.6 L162.1 211 L150.6 207 L132 213.4 L134.3 222.3 L130.1 232.5 L131.1 247.6 L119.6 268.2 L115.1 284.7 L104.5 301.2 L104.5 318.3 L108.7 327.6 L107.4 331.7 L126 331.1 L131.1 351.4 L135.6 356 L136.5 353.7 L140.4 360.7 L148.7 390.8 L145.5 389.4 L143.6 381.8 L140.4 381.5 L139.7 375.2 L136.5 376.3 L136.5 380.1 L144.8 392 L150.3 392.3 L164 401.6 L179.4 401.6 L198.6 419.5 L191.2 431.7 L185.2 432.9 L181.3 429.1 L166.9 436.9 L162.8 433.2 L166 427.7 L165 419.5 L159.2 419.3 L155.7 413.2 L142.6 410.5 L139.7 406.8 L137.2 407.1 L135.2 413.7 L121.8 401 L122.4 394.3 L117 391.1 L118.6 387.1 L110.9 386.8 L107.7 379.5 L102 376.6 L101 371.7 L92.7 366.8 L89.8 361 L86 358.6 L78.9 363 L75.1 356.3 L75.1 346.2 L89.8 305 L91.7 291.4 L105.5 278.3 L118.9 258.9 L112.5 236.5 L106.4 231 L103.6 222.6 L103.9 202.6 L97.2 193 L85.6 184.1 L73.8 166.1 L73.5 159.7 L85.3 154.8 L86.3 135 L93.6 131.3 L95.9 126.3 L94.3 124.3 L88.5 126.9 L81.5 108.1 L58.1 84.3 L55.6 70.1 L49.8 68.1 L47.6 63.4 L59.4 61.4 L58.1 51.5 L61.6 36.2 L68 27.8 L79.2 29.5 L96.8 27.2 L101.6 17.6 L115.1 16.2 L114.1 10.1 L122.4 10.9 L127.9 8.3 Z"
                  />
                  <g className="xray-lines" clipPath="url(#thailand-clip)">
                    <path d="M60 50H320 M55 80H320 M75 110H320 M80 140H320 M80 170H320 M90 200H320 M95 230H320 M95 260H320 M95 290H300 M90 320H280 M90 350H250 M90 380H220 M100 410H205" />
                    <path d="M120 8V450 M160 8V450 M200 8V450 M240 8V450 M280 8V220" />
                  </g>
                  <path
                    className="route-line route-first"
                    d="M147.5 201.6 Q165 184 176 161 L187 146 L190 128 L207 111 Q215 102 222.2 95.5"
                  />
                  <path className="route-line route-final" d="M222.2 95.5 Q230 88 235.7 87" />
                  <circle className="route-pulse pulse-bangkok" cx="147.5" cy="201.6" r="5.5" />
                  <circle className="route-pulse pulse-udon" cx="222.2" cy="95.5" r="5.5" />
                  <circle className="route-pulse pulse-bandung" cx="235.7" cy="87" r="7" />
                  <text className="route-label label-bangkok" x="154" y="206">กรุงเทพมหานคร</text>
                  <text className="route-label label-udon" x="229" y="101">อุดรธานี</text>
                  <text className="route-label label-bandung" x="244" y="79">คูโบต้า บ้านดุง</text>
                </svg>
                <span className="map-caption">THAILAND · ROUTE TO OUR STORE</span>
              </div>

              <div className="location-details">
                <div className="shop-photo">
                  <img src="/kubota-bandung-shop.png" alt="ภาพมุมสูงของร้านคูโบต้า บ้านดุง" />
                  <span className="roof-target" aria-hidden="true">
                    <span className="roof-target-ring" />
                    <span className="roof-target-pin"><span>K</span></span>
                    <span className="roof-target-label">คูโบต้า บ้านดุง</span>
                  </span>
                  <span className="photo-caption">BAN DUNG · UDON THANI</span>
                </div>
                <div className="location-copy">
                  <p className="eyebrow">DESTINATION</p>
                  <h3>คูโบต้า บ้านดุง</h3>
                  <p>อำเภอบ้านดุง จังหวัดอุดรธานี</p>
                  <a
                    className="ghost-button map-link"
                    href="https://www.google.com/maps/search/?api=1&query=Kubota+Ban+Dung+Udon+Thani+Thailand"
                    target="_blank"
                    rel="noreferrer"
                  >
                    เปิดแผนที่นำทาง <span aria-hidden="true">↗</span>
                  </a>
                </div>
              </div>
            </div>
            <p className="location-note">
              เส้นทางและหมุดบนภาพเป็นภาพนำเสนอเบื้องต้น ตำแหน่งจริงบนแผนที่เปิดผ่าน Google Maps
            </p>
          </section>
        </div>
      )}
    </main>
  );
}
