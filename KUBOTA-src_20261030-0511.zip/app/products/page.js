import Link from 'next/link';

const catalog = [
  {
    slug: 'tractors',
    label: 'รถไถ / แทรกเตอร์',
    title: 'แทรกเตอร์คูโบต้า',
    subtitle: 'KUBOTA TRACTORS',
    description: 'ขุมพลังสำหรับงานไร่ งานนา และงานสวน ตั้งแต่ 21 ถึง 173 แรงม้า พร้อมเทคโนโลยีควบคุมที่แม่นยำและประหยัดน้ำมัน',
    highlight: 'รุ่น B · L · MU · M',
    image:
      'https://images.unsplash.com/photo-1791807028600-b78d90e786e9?auto=format&fit=crop&w=1200&q=80',
  },
  {
    slug: 'harvesters',
    label: 'รถเกี่ยวข้าว',
    title: 'รถเกี่ยวนวดข้าวคูโบต้า',
    subtitle: 'KUBOTA HARVESTERS',
    description: 'ข้อมูลรุ่น สเปก และภาพถ่ายจริงอยู่ระหว่างรวบรวมและยืนยันกับทีมงาน',
    highlight: 'รอข้อมูลที่ยืนยัน',
    image: null,
    placeholderMark: 'HARVESTERS',
  },
  {
    slug: 'excavators',
    label: 'รถขุด / มินิขุด',
    title: 'รถขุดคูโบต้า',
    subtitle: 'KUBOTA EXCAVATORS',
    description: 'ข้อมูลรุ่น สเปก และภาพถ่ายจริงอยู่ระหว่างรวบรวมและยืนยันกับทีมงาน',
    highlight: 'รอข้อมูลที่ยืนยัน',
    image: null,
    placeholderMark: 'EXCAVATORS',
  },
  {
    slug: 'tractor-implements',
    label: 'อุปกรณ์ต่อพ่วง',
    title: 'อุปกรณ์ต่อพ่วงแทรกเตอร์',
    subtitle: 'KUBOTA IMPLEMENTS',
    description: 'รายการอุปกรณ์ สเปก และภาพถ่ายจริงอยู่ระหว่างรวบรวมและยืนยันกับทีมงาน',
    highlight: 'รอข้อมูลที่ยืนยัน',
    image: null,
    placeholderMark: 'IMPLEMENTS',
  },
];

export default function ProductCatalogPage() {
  return (
    <main className="product-category-page">
      <header className="product-page-header">
        <div className="product-breadcrumbs">
          <Link href="/">หน้าแรก</Link>
          <span aria-hidden="true" className="breadcrumb-separator">/</span>
          <span>สินค้าใหม่มือหนึ่ง</span>
        </div>
        <p className="eyebrow">NEW MACHINERY CATALOG · KUBOTA BAN DUNG</p>
        <h1>สินค้าใหม่มือหนึ่ง</h1>
        <p className="product-page-description">
          สัมผัสยนตรกรรมและเครื่องจักรกลการเกษตรรุ่นล่าสุดจากคูโบต้า ออกแบบเพื่อตอบโจทย์เกษตรกรไทยด้วยความทนทาน 
          ประหยัดน้ำมัน และคุ้มค่าทุกการลงทุน พร้อมการรับประกันและบริการดูแลจากทีมงาน คูโบต้า บ้านดุง
        </p>
      </header>

      <section className="product-catalog-grid" aria-label="หมวดสินค้าใหม่มือหนึ่ง KUBOTA PARTPRO">
        {catalog.map((item) => (
          <Link className="product-catalog-card" href={`/products/${item.slug}`} key={item.slug}>
            {item.image ? (
              <div
                className="catalog-card-visual"
                style={{ backgroundImage: `url('${item.image}')` }}
                role="img"
                aria-label={item.title}
              />
            ) : (
              <div
                className="catalog-card-visual is-placeholder"
                role="img"
                aria-label={`${item.title} (รอภาพถ่ายจริงจากทีมงาน)`}
              >
                <span className="catalog-placeholder-mark" aria-hidden="true">
                  {item.placeholderMark}
                </span>
                <span className="catalog-placeholder-note">รอภาพถ่ายจริง</span>
              </div>
            )}
            <div className="catalog-card-body">
              <div>
                <div className="catalog-card-header-row">
                  <span className="catalog-card-kicker">{item.subtitle}</span>
                  <span className="catalog-card-highlight">{item.highlight}</span>
                </div>
                <h2>{item.title}</h2>
                <p>{item.description}</p>
              </div>
              <div className="catalog-card-meta">
                <span className="catalog-card-label">{item.label}</span>
                <span className="catalog-card-action">
                  <span>ดูหมวดนี้</span>
                  <span className="catalog-arrow-icon" aria-hidden="true">↗</span>
                </span>
              </div>
            </div>
          </Link>
        ))}
      </section>
    </main>
  );
}
