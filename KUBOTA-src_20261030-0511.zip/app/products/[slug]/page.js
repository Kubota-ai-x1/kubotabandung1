import Link from 'next/link';
import Image from 'next/image';
import { notFound } from 'next/navigation';
import shopConfig from '../../../lib/shopConfig';
import CombineSeriesCatalog from '../../../lib/components/CombineSeriesCatalog';

const categories = {
  tractors: {
    label: 'รถไถ',
    eyebrow: 'KUBOTA TRACTORS · NEW MACHINERY',
    title: 'แทรกเตอร์คูโบต้า',
    description: 'เลือกชมกลุ่มแทรกเตอร์คูโบต้าตามกำลังเครื่องยนต์และขนาดพื้นที่ ตั้งแต่ไร่สวนขนาดเล็กไปจนถึงแปลงนาและไร่อ้อยขนาดใหญ่',
    image:
      'https://images.unsplash.com/photo-1791807028600-b78d90e786e9?auto=format&fit=crop&w=2000&q=85',
    families: [
      {
        name: 'รุ่น B Series',
        power: '21–27 แรงม้า',
        desc: 'คล่องตัวในสวนผลไม้ ยกร่อง ร่องอ้อย แปลงผัก รัศมีวงเลี้ยวแคบ ใช้งานสะดวกในพื้นที่จำกัด',
        href: '/products/tractors/b-series',
        image: 'https://images.unsplash.com/photo-1791807028600-b78d90e786e9?auto=format&fit=crop&w=900&q=80',
      },
      {
        name: 'รุ่น L และ L Special',
        power: '32–52 แรงม้า',
        desc: 'ขวัญใจเกษตรกรไทย ลุยงานนาดินหล่มและงานไร่ได้อย่างยอดเยี่ยม พร้อมตัวเลือกห้องโดยสารปรับอากาศ Air Cabin',
        href: '/products/tractors/l-series',
        image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=900&q=80',
      },
      {
        name: 'รุ่น MU Series',
        power: '49–57 แรงม้า',
        desc: 'แรงบิดสูง ทรงพลังในงานไร่มันสำปะหลัง ไร่อ้อย งานเตรียมดินลึก ทนทานและประหยัดน้ำมันระดับพรีเมียม',
        href: '/products/tractors/mu-series',
        image: 'https://images.unsplash.com/photo-1516937941344-00b4e0337589?auto=format&fit=crop&w=900&q=80',
      },
      {
        name: 'รุ่น M Series',
        power: '60–173 แรงม้า',
        desc: 'เครื่องจักรกลหนักเพื่อแปลงเกษตรขนาดใหญ่และผู้รับเหมา งานบุกเบิก ลากจูง และควบคุมอุปกรณ์ต่อพ่วงสเปกสูง',
        href: '/products/tractors/m-series',
        image: 'https://images.unsplash.com/photo-1500382017468-9049fed747ef?auto=format&fit=crop&w=900&q=80',
      },
    ],
  },
  // หมวดด้านล่างนี้ยังไม่มีข้อมูลรุ่น สเปก ราคา หรือภาพจริงที่ยืนยันแล้ว
  // awaitingData: true = แสดงสถานะ "รอข้อมูล" แทนรายการสินค้า (ห้ามเติมข้อมูลที่ยังไม่ยืนยัน)
  harvesters: {
    label: 'รถเกี่ยว',
    eyebrow: 'KUBOTA HARVESTERS · NEW MACHINERY',
    title: 'รถเกี่ยวนวดข้าวคูโบต้า',
    description: 'นวัตกรรมการเก็บเกี่ยวที่มีประสิทธิภาพสูง ได้งานไว มั่นใจ เกี่ยวได้เต็มที่',
    image: null,
    placeholderMark: 'HARVESTERS',
    families: [],
  },
  excavators: {
    label: 'รถขุด',
    eyebrow: 'KUBOTA EXCAVATORS · NEW MACHINERY',
    title: 'รถขุดคูโบต้า',
    description: 'หมวดรถขุด ข้อมูลรุ่น สเปก และภาพถ่ายจริงอยู่ระหว่างรวบรวมและยืนยันกับทีมงาน คูโบต้า บ้านดุง',
    image: null,
    placeholderMark: 'EXCAVATORS',
    awaitingData: true,
    families: [],
  },
  'tractor-implements': {
    label: 'อุปกรณ์ต่อพ่วง',
    eyebrow: 'KUBOTA TRACTOR IMPLEMENTS',
    title: 'อุปกรณ์ต่อพ่วงแทรกเตอร์คูโบต้า',
    description: 'หมวดอุปกรณ์ต่อพ่วงแทรกเตอร์ รายการอุปกรณ์ สเปก และภาพถ่ายจริงอยู่ระหว่างรวบรวมและยืนยันกับทีมงาน คูโบต้า บ้านดุง',
    image: '/images/tractor-implements-banner.jpg',
    awaitingData: true,
    families: [],
  },
};

const awaitingSlots = [
  'ชื่อรุ่นหรือรายการ',
  'สเปกหลักที่ยืนยันแล้ว',
  'ภาพถ่ายจริง',
  'ราคาแนะนำ',
];

const siblingLinks = [
  { slug: 'tractors', label: 'รถไถ' },
  { slug: 'harvesters', label: 'รถเกี่ยว' },
  { slug: 'excavators', label: 'รถขุด' },
  { slug: 'tractor-implements', label: 'อุปกรณ์ต่อพ่วง' },
];

export function generateStaticParams() {
  return Object.keys(categories).map((slug) => ({ slug }));
}

export default async function ProductCategoryPage({ params }) {
  const { slug } = await params;
  const category = categories[slug];

  if (!category) notFound();

  return (
    <main className="product-detail-page">
      <div className="product-breadcrumbs-wrap">
        <div className="product-breadcrumbs">
          <Link href="/">หน้าแรก</Link>
          <span aria-hidden="true" className="breadcrumb-separator">/</span>
          <Link href="/products">สินค้าใหม่มือหนึ่ง</Link>
          <span aria-hidden="true" className="breadcrumb-separator">/</span>
          <span>{category.label}</span>
        </div>
      </div>

      {slug === 'tractor-implements' ? (
        <section className="tractor-implements-hero" aria-labelledby="product-category-title">
          <div className="tractor-implements-banner-wrap">
            <Image
              className="tractor-implements-banner"
              src={category.image}
              alt="แทรกเตอร์คูโบต้าพร้อมอุปกรณ์ต่อพ่วงไถพรวน"
              width={1180}
              height={510}
              priority
            />
          </div>
          <div className="tractor-implements-copy">
            <p className="eyebrow">{category.eyebrow}</p>
            <h1 id="product-category-title">{category.title}</h1>
            <p>{category.description}</p>
          </div>
        </section>
      ) : !category.image ? (
        <section
          className="tractor-feature-hero category-placeholder-hero"
          aria-labelledby="product-category-title"
        >
          <span className="category-placeholder-mark" aria-hidden="true">
            {category.placeholderMark}
          </span>
          <div className="tractor-hero-copy">
            <p className="eyebrow">{category.eyebrow}</p>
            <h1 id="product-category-title">{category.title}</h1>
            <p>{category.description}</p>
          </div>
          <span className="hero-image-caption">รอภาพถ่ายจริงจากทีมงาน</span>
        </section>
      ) : (
        <section
          className="tractor-feature-hero"
          style={{
            backgroundImage: `linear-gradient(90deg, rgba(6, 8, 12, 0.84) 0%, rgba(6, 8, 12, 0.45) 45%, rgba(6, 8, 12, 0.1) 80%), url('${category.image}')`,
          }}
        >
          <div className="tractor-hero-copy">
            <p className="eyebrow">{category.eyebrow}</p>
            <h1>{category.title}</h1>
            <p>{category.description}</p>
          </div>
          <span className="hero-image-caption">ภาพเพื่อการประชาสัมพันธ์</span>
        </section>
      )}

      {slug === 'harvesters' ? (
        <CombineSeriesCatalog />
      ) : category.families.length > 0 ? (
        <section className="product-lineup" aria-label={`กลุ่มตระกูล ${category.label}`}>
          <div className="section-title-wrap">
            <p className="eyebrow">EXPLORE SERIES LINEUP</p>
            <h2>กลุ่มตระกูล{category.title}</h2>
            <p className="section-subtitle">เลือกรุ่นที่ตรงกับขนาดแปลงและลักษณะงานของคุณเพื่อดูรายละเอียดสเปกและราคา</p>
          </div>
          <div className="product-lineup-grid">
            {category.families.map((family, index) => (
              <article className="model-card" key={`${family.name}-${family.power}-${index}`}>
                <div
                  className="model-card-image"
                  role="img"
                  aria-label={`ภาพประกอบ ${family.name}`}
                  style={{ backgroundImage: `url('${family.image}')` }}
                >
                  <span className="model-card-badge">{family.power}</span>
                </div>
                <div className="model-card-body">
                  <div>
                    <h3>{family.name}</h3>
                    <p className="model-card-desc">{family.desc}</p>
                  </div>
                  <div className="model-card-footer">
                    <Link className="ghost-button mini-button" href={family.href}>
                      ดูรุ่นย่อยทั้งหมด <span aria-hidden="true">↗</span>
                    </Link>
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>
      ) : (
        <>
          <section className="category-awaiting" aria-label={`สถานะข้อมูล${category.label}`}>
            <div className="category-awaiting-card">
              <div className="showroom-prep-badge">
                <span className="prep-pulse-dot" />
                <span>สถานะ · รอข้อมูลที่ยืนยัน</span>
              </div>
              <h2>ข้อมูล{category.label}อยู่ระหว่างรวบรวม</h2>
              <p className="showroom-prep-lead">
                ขณะนี้ยังไม่มีรายการรุ่น สเปก ราคา หรือภาพถ่ายจริงของหมวดนี้ที่ยืนยันแล้ว
                จะเผยแพร่เมื่อได้รับข้อมูลจากทีมงาน คูโบต้า บ้านดุง หากสนใจสามารถสอบถามทีมงานโดยตรงได้
              </p>
              <ul className="category-awaiting-slots" aria-label="ข้อมูลที่รอการยืนยัน">
                {awaitingSlots.map((slot) => (
                  <li className="category-awaiting-slot" key={slot}>
                    <span className="category-awaiting-slot-name">{slot}</span>
                    <span className="category-awaiting-slot-status">รอข้อมูล</span>
                  </li>
                ))}
              </ul>
              <div className="showroom-prep-actions">
                <a
                  className="solid-button"
                  href={shopConfig.links.line}
                  target="_blank"
                  rel="noreferrer"
                >
                  สอบถามข้อมูล{category.label}ทาง LINE <span aria-hidden="true">↗</span>
                </a>
              </div>
            </div>
          </section>

          <nav className="category-sibling-nav" aria-label="หมวดสินค้าอื่น">
            <p className="eyebrow">หมวดสินค้าอื่น</p>
            <div className="category-sibling-links">
              {siblingLinks
                .filter((item) => item.slug !== slug)
                .map((item) => (
                  <Link
                    className="ghost-button mini-button"
                    href={`/products/${item.slug}`}
                    key={item.slug}
                  >
                    {item.label} <span aria-hidden="true">↗</span>
                  </Link>
                ))}
            </div>
          </nav>
        </>
      )}

      <section className="product-page-cta" id="product-contact">
        <div className="product-cta-copy">
          <p className="eyebrow">CONSULTATION & ASSISTANCE</p>
          <h2>{category.awaitingData ? `ต้องการสอบถามเรื่อง ${category.label}?` : `ต้องการปรึกษาเรื่อง ${category.label}?`}</h2>
          <p>
            {category.awaitingData
              ? 'ติดต่อทีมงาน คูโบต้า บ้านดุง เพื่อสอบถามข้อมูลหมวดนี้โดยตรง'
              : 'ทีมงานคูโบต้า บ้านดุง ยินดีให้คำแนะนำรุ่นที่เหมาะสม คำนวณงวดผ่อน และตอบทุกข้อสงสัยอย่างเป็นกันเอง'}
          </p>
        </div>
        <div className="product-page-actions">
          <Link href="/products" className="ghost-button">
            กลับไปเลือกหมวดอื่น <span aria-hidden="true">↗</span>
          </Link>
          <a
            href={shopConfig.links.line}
            target="_blank"
            rel="noreferrer"
            className="solid-button"
          >
            แชทคุยกับเรา <span aria-hidden="true">↗</span>
          </a>
        </div>
      </section>
    </main>
  );
}
