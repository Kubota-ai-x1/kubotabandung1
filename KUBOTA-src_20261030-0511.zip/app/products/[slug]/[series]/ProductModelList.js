'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import shopConfig from '../../../../lib/shopConfig';

export default function ProductModelList({ products, series }) {
  const [visibleCount, setVisibleCount] = useState(products.length);
  const [contactProduct, setContactProduct] = useState(null);
  const visibleProducts = products.slice(0, visibleCount);
  const seriesLabel = series.replace('-series', '').toUpperCase();

  useEffect(() => {
    if (!contactProduct) return undefined;

    const closeOnEscape = (event) => {
      if (event.key === 'Escape') setContactProduct(null);
    };

    document.body.style.overflow = 'hidden';
    window.addEventListener('keydown', closeOnEscape);
    return () => {
      document.body.style.overflow = '';
      window.removeEventListener('keydown', closeOnEscape);
    };
  }, [contactProduct]);

  return (
    <>
      <section className="tractor-model-grid" aria-label={`สินค้ารุ่น ${seriesLabel} ทั้งหมด`}>
        {visibleProducts.map((product) => {
          const isFeatured = series === 'l-series' && product.name.toLowerCase().includes('cabin');
          return (
            <article
              className={`tractor-model-card${isFeatured ? ' is-featured' : ''}`}
              key={product.name}
            >
              <div
                className="tractor-model-image"
                aria-label={`พื้นที่ภาพสินค้า ${product.name}`}
              >
                <div className="model-image-topbar">
                  <span className="model-kicker-tag">KUBOTA GENUINE</span>
                  {product.power && (
                    <span className="model-power-pill">{product.power}</span>
                  )}
                </div>
                <div className="model-image-center">
                  <span className="model-watermark-text" aria-hidden="true">KUBOTA</span>
                  <strong className="model-title-text">{product.name}</strong>
                  <span className="model-caption-text">รุ่นสเปกมาตรฐานโรงงานคูโบต้า</span>
                </div>
              </div>
              <div className="tractor-model-copy">
                <div>
                  <div className="tractor-model-heading-wrap">
                    <h2>{product.name}</h2>
                    {isFeatured && <span className="featured-chip">แอร์เคบิน (Air Cabin)</span>}
                  </div>
                  <div className="tractor-model-meta-row">
                    <span className="tractor-model-power">
                      <span aria-hidden="true">⚡</span> กำลังเครื่องยนต์ {product.power}
                    </span>
                    {product.price && (
                      <div className="tractor-model-price-wrap">
                        <span className="price-label">ราคาแนะนำ</span>
                        <span className="tractor-model-price">{product.price}</span>
                      </div>
                    )}
                  </div>
                  {product.description && <p className="tractor-model-desc">{product.description}</p>}
                </div>
                <div className="tractor-model-actions">
                  <Link
                    className="ghost-button mini-button model-detail-button"
                    href={`/products/tractors/${series}/${encodeURIComponent(product.name)}/details`}
                  >
                    รายละเอียดสินค้า <span aria-hidden="true">↗</span>
                  </Link>
                  <button
                    className="solid-button mini-button"
                    type="button"
                    onClick={() => setContactProduct(product)}
                  >
                    สอบถามโปรโมชั่น & ข้อเสนอพิเศษ <span aria-hidden="true">↗</span>
                  </button>
                </div>
              </div>
            </article>
          );
        })}
      </section>

      {visibleCount < products.length && (
        <button
          className="ghost-button load-more-button"
          type="button"
          onClick={() => setVisibleCount((count) => Math.min(count + 6, products.length))}
        >
          แสดงรุ่นย่อยเพิ่มเติม <span aria-hidden="true">↓</span>
        </button>
      )}

      {contactProduct && (
        <div className="product-contact-backdrop" onClick={() => setContactProduct(null)}>
          <section
            className="product-contact-dialog"
            role="dialog"
            aria-modal="true"
            aria-labelledby="product-contact-title"
            onClick={(event) => event.stopPropagation()}
          >
            <button
              className="product-contact-close"
              type="button"
              aria-label="ปิดช่องทางติดต่อ"
              onClick={() => setContactProduct(null)}
            >
              ×
            </button>
            <div className="dialog-header-wrap">
              <p className="eyebrow">KUBOTA BAN DUNG · DIRECT INQUIRY</p>
              <h2 id="product-contact-title">ขอข้อมูลและราคาโปรโมชั่น</h2>
              <div className="dialog-product-summary">
                <strong>{contactProduct.name}</strong>
                {contactProduct.power && <span>กำลัง {contactProduct.power}</span>}
                {contactProduct.price && <span className="dialog-price">{contactProduct.price}</span>}
              </div>
              <p className="dialog-lead">
                เลือกช่องทางติดต่อเพื่อคุยกับทีมงาน คูโบต้า บ้านดุง ยินดีคำนวณค่างวด ประเมินเงื่อนไข และแนะนำโปรโมชั่นที่ดีที่สุด
              </p>
            </div>

            <div className="product-contact-options">
              <a
                className="product-contact-option line-option"
                href={shopConfig.links.line}
                target="_blank"
                rel="noreferrer"
              >
                <span className="contact-channel-icon line-channel" aria-hidden="true">
                  <svg viewBox="0 0 32 32">
                    <path d="M16 4C9.1 4 3.5 8.6 3.5 14.3c0 3.5 2.1 6.6 5.4 8.4l-.8 4.4 5-2.7c.9.2 1.9.3 2.9.3 6.9 0 12.5-4.6 12.5-10.4S22.9 4 16 4Z" />
                    <path d="M10.2 12h1.6v5h2.5v1.5h-4.1V12Zm5.1 0h1.6v6.5h-1.6V12Zm3 0h1.5l2.5 3.8V12h1.6v6.5h-1.5l-2.5-3.8v3.8h-1.6V12Z" />
                  </svg>
                </span>
                <div className="channel-text">
                  <strong>แชทผ่าน LINE Official</strong>
                  <span>ตอบไว สอบถามใบเสนอราคาและเอกสารได้ทันที</span>
                </div>
                <span className="channel-arrow" aria-hidden="true">↗</span>
              </a>

              <a
                className="product-contact-option phone-option"
                href={`tel:${shopConfig.links.phone}`}
              >
                <span className="contact-channel-icon phone-channel" aria-hidden="true">
                  <svg viewBox="0 0 24 24">
                    <path d="M7.1 3.5h2.5l1.2 4.1-1.7 1.6a15.4 15.4 0 0 0 5.7 5.7l1.6-1.7 4.1 1.2v2.5c0 1.1-.9 2-2 2A15.5 15.5 0 0 1 5.1 5.5c0-1.1.9-2 2-2Z" />
                  </svg>
                </span>
                <div className="channel-text">
                  <strong>โทรคุยกับทีมฝ่ายขาย</strong>
                  <span>{shopConfig.links.phone} (เปิดทำการ {shopConfig.hours.open} - {shopConfig.hours.close} น.)</span>
                </div>
                <span className="channel-arrow" aria-hidden="true">↗</span>
              </a>
            </div>
          </section>
        </div>
      )}
    </>
  );
}
