import Link from 'next/link';
import shopConfig from '../../lib/shopConfig';

export default function ProductLayout({ children }) {
  return (
    <div className="product-layout-shell">
      <header className="product-site-header">
        <div className="product-header-left">
          <Link className="brand-mark" href="/" aria-label="KUBOTA PARTPRO หน้าแรก">
            <span className="brand-kubota">KUBOTA</span>
            <span className="brand-part">PARTPRO</span>
          </Link>
          <span className="header-divider-dot" aria-hidden="true">·</span>
          <span className="header-location-tag">บ้านดุง อุดรธานี</span>
        </div>
        <nav aria-label="เมนูสินค้าใหม่มือหนึ่ง" className="product-site-nav">
          <Link href="/products" className="nav-pill-item">
            ภาพรวม
          </Link>
          <Link href="/products/tractors" className="nav-pill-item">
            รถไถ
          </Link>
          <Link href="/products/harvesters" className="nav-pill-item">
            รถเกี่ยว
          </Link>
          <Link href="/products/excavators" className="nav-pill-item">
            รถขุด
          </Link>
          <Link href="/products/tractor-implements" className="nav-pill-item">
            อุปกรณ์ต่อพ่วง
          </Link>
        </nav>
        <div className="product-header-right">
          <a
            href={shopConfig.links.line}
            target="_blank"
            rel="noreferrer"
            className="header-contact-btn"
          >
            <span>คุยกับเรา LINE</span>
            <span aria-hidden="true">↗</span>
          </a>
        </div>
      </header>

      {children}

      <footer className="product-site-footer">
        <div className="footer-content-wrap">
          <div className="footer-brand-col">
            <Link className="brand-mark" href="/" aria-label="กลับหน้าแรก KUBOTA PARTPRO">
              <span className="brand-kubota">KUBOTA</span>
              <span className="brand-part">PARTPRO</span>
            </Link>
            <p className="footer-tagline">
              ผู้แทนจำหน่ายและบริการเครื่องจักรกลการเกษตรและอะไหล่แท้ คูโบต้า อ.บ้านดุง จ.อุดรธานี
            </p>
          </div>
          <div className="footer-contact-col">
            <div className="footer-contact-item">
              <span className="footer-contact-label">เปิดทำการ</span>
              <span className="footer-contact-val">จันทร์ – อาทิตย์ {shopConfig.hours.open} – {shopConfig.hours.close} น.</span>
            </div>
            <div className="footer-contact-item">
              <span className="footer-contact-label">สอบถามฝ่ายขาย</span>
              <span className="footer-contact-val">{shopConfig.links.phone}</span>
            </div>
          </div>
          <div className="footer-nav-col">
            <Link href="/" className="footer-back-link">
              <span>กลับสู่หน้าหลัก</span>
              <span aria-hidden="true">↑</span>
            </Link>
          </div>
        </div>
      </footer>
    </div>
  );
}
