import './globals.css';

export const metadata = {
  title: 'KUBOTA PARTPRO | คูโบต้า บ้านดุง',
  description: 'KUBOTA PARTPRO By คูโบต้า บ้านดุง',
};

export default function RootLayout({ children }) {
  return (
    <html lang="th">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=Barlow+Condensed:wght@700;800&family=Inter:wght@300;400;600&family=Prompt:wght@200;300;400;500&display=swap" rel="stylesheet" />
      </head>
      <body>
        {children}
      </body>
    </html>
  );
}
