# KUBOTA PARTPRO

This project is a Next.js storefront and landing page for KUBOTA PARTPRO. The current work is organized around a single branded landing experience with a product estimate modal and shared config values.

## Structure

- `app/` — App Router pages and global styles
- `lib/` — Firebase and shop configuration helpers
- `lib/components/` — Reusable UI sections

## Commands

```bash
npm install
npm run dev
npm run build
```

## Notes

- The production build is currently validated with the Next.js App Router setup.
- Generated folders such as `.next/` and `node_modules/` are intentionally excluded from source organization.
